To anyone want to edit this pack:
If you want to change the default pack of tacz, you should turn "DefaultPackDebug"
to "true" in the config file "tacz-pre.toml" in .minecraft/tacz (the gunpack folder)
or the content will be overridden everytime you start the game.
If things you edit been overwritten by accident, you can find the backup of the old
pack in .minecraft/tacz_backup